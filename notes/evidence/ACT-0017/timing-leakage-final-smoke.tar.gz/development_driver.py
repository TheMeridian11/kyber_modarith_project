import sys,json,zlib,hashlib,copy
from pathlib import Path
from types import SimpleNamespace
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));import run_timing_leakage as run;import run_validation as v;import collect_run_metadata as meta
G=R/'.git'
def ob(h):
 b=zlib.decompress((G/'objects'/h[:2]/h[2:]).read_bytes());assert hashlib.sha1(b).hexdigest()==h;return b.split(b'\0',1)[1]
def tree(h,p=''):
 d=ob(h);i=0
 while i<len(d):
  j=d.index(b'\0',i);mode,n=d[i:j].split(b' ',1);c=d[j+1:j+21].hex();i=j+21;n=p+n.decode()
  if mode==b'40000':yield from tree(c,n+'/')
  elif mode!=b'160000':yield n,c
maps={}
for h in run.load_protocol()['restoration_commits'].values():maps[h]=dict(tree(ob(h).splitlines()[0].split()[1].decode()))
run.read_blob=lambda h,n:ob(maps[h]['implementation/kyber-optimised-ref/'+n])
meta.git=lambda *args: ''
v.check_source_state=lambda *args:None
p=run.load_protocol();p['samples_per_process']=4000;p['minimum_per_class_per_view']=100;p['looks']=[2000,4000]
run.load_protocol=lambda:p
rd=Path('/tmp/kyber-act0017-leak-final');rd.mkdir()
snapshot=json.loads((R/'results/EXP-007/RUN-0001/metadata.json').read_text());(rd/'metadata.json').write_text(json.dumps(snapshot,indent=2)+'\n')
code=run.execute(rd,snapshot,p,SimpleNamespace(experiment='DEVELOPMENT-ACT-0017',run='support-smoke',cpu=0))
print('DEVELOPMENT EXIT',code)
