import csv,gzip,hashlib,io,json,pathlib,sys,tarfile
ROOT=pathlib.Path('/home/meridian/Honours_2026_PQC/kyber_modarith_project');sys.path.insert(0,str(ROOT/'scripts'))
import analyse_final_comparison as analysis
import run_timing as timing
import run_final_comparison as runner
run=pathlib.Path('/tmp/kyber-act0018-final-comparison-smoke');m=json.loads((run/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert m['development_only'] and m['status']=='completed' and m['provenance_recheck']=='pass'
assert len(m['steps'])==225 and len(m['datasets'])==108 and len(m['assembly'])==108
for s in m['steps']:
 assert s['status']=='completed' and s['exit_code']==0
 for stream in ('stdout','stderr'):assert sha(run/s[stream])==s[stream+'_sha256']
for s in m['steps']:
 if s['label'].startswith('build-'):assert (run/s['stderr']).stat().st_size==0
for name,digest in m['support_file_sha256'].items():assert sha(ROOT/name)==digest
summaries=[]
for d in m['datasets']:
 assert sha(run/d['path'])==d['sha256']
 for row in timing.summarise_csv(run/d['path'],d['parameter'],1000,d['block']):
  row['block']=row.pop('repetition');summaries.append(dict(variant=d['variant'],position=d['position'],fixture_seed=d['fixture_seed'],**row))
pairs,aggregate=analysis.derive(summaries,12,1)
for name,rows in (('process-summary',summaries),('paired-comparison',pairs),('comparison',aggregate)):
 b=io.StringIO(newline='');w=csv.DictWriter(b,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
 assert (run/m['derived'][name]['path']).read_bytes()==b.getvalue().encode()
try:analysis.read_run(run)
except ValueError:pass
else:raise AssertionError('Development passed formal analysis gate')
out=ROOT/'notes/evidence/ACT-0018';archive=out/'final-comparison-support-smoke.tar.gz'
files={('run/'+p.relative_to(run).as_posix()):p for p in run.rglob('*') if p.is_file() and 'build' not in p.relative_to(run).parts}
for name in (*m['support_file_sha256'],'tests/test_final_comparison_analysis.py'):files['support/'+name]=ROOT/name
files['development_driver.py']=pathlib.Path('/tmp/kyber_act0018_smoke.py')
files['verify_support.py']=pathlib.Path(__file__)
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,path in sorted(files.items()):
    data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
 for name,path in files.items():assert tar.extractfile(name).read()==path.read_bytes()
record=dict(activity_id='ACT-0018',record_type='uncommitted-development-support-review',status='completed',formal_performance_result=False,
 source_commit=m['source_commit'],manifest_sha256=sha(run/'manifest.json'),support_sha256=m['support_file_sha256'],
 checks=dict(builds=9,build_warning_bytes=0,assembly_matches=108,steps=225,measurement_processes=108,
 duration_rows=324000,derived_tables_reproduced=3,development_rejected_by_formal_analysis=True),
 archive_sha256=sha(archive),archive_files=len(files),driver_sha256=sha('/tmp/kyber_act0018_smoke.py'),
 limitation=m['development_limitation'],method='Historical blobs read directly with SHA-1 verification; all production bytes and acceptance gates except Git commit/clean-tree checks retained')
(out/'final-comparison-support-review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='support_sha256'},indent=2))
