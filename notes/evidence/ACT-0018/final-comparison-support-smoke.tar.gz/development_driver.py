import copy,hashlib,json,os,pathlib,sys,zlib
ROOT=pathlib.Path('/home/meridian/Honours_2026_PQC/kyber_modarith_project')
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'))
import run_final_comparison as run
G=ROOT/'.git'
def obj(h):
 raw=zlib.decompress((G/'objects'/h[:2]/h[2:]).read_bytes());assert hashlib.sha1(raw).hexdigest()==h;return raw.split(b'\0',1)[1]
def tree(h,p=''):
 d=obj(h);i=0
 while i<len(d):
  j=d.index(b'\0',i);mode,n=d[i:j].split(b' ',1);c=d[j+1:j+21].hex();i=j+21;n=p+n.decode()
  if mode==b'40000':yield from tree(c,n+'/')
  elif mode!=b'160000':yield n,c
maps={}
def read_blob(commit,name):
 if commit not in maps:maps[commit]=dict(tree(obj(commit).splitlines()[0].decode().split()[1]))
 return obj(maps[commit]['implementation/kyber-optimised-ref/'+name])
head=(G/(G/'HEAD').read_text().strip()[5:]).read_text().strip()
def source_check(commit,files):
 assert commit==head==(G/(G/'HEAD').read_text().strip()[5:]).read_text().strip()
 assert run.validation.source_snapshot()==files
run.historical.read_blob=read_blob
run.validation.check_source_state=source_check
# Only formal Git commit-presence/clean-tree gates are bypassed in this development driver.
def development_git(*args,**kwargs):
 assert args[:2]==('cat-file','-e');return ''
run.metadata.git=development_git
original_save=run.validation.save_manifest
def save(directory,m):
 m['development_only']=True
 m['development_limitation']='Uncommitted support; Git presence/cleanliness gates replaced only in this driver; environment snapshot reused from EXP-008. Not a formal performance result.'
 original_save(directory,m)
run.validation.save_manifest=save
out=pathlib.Path('/tmp/kyber-act0018-final-comparison-smoke');out.mkdir()
snapshot=json.loads((ROOT/'results/EXP-008/RUN-0001/metadata.json').read_text())
snapshot['record_type']='development-metadata-reuse';snapshot['development_only']=True
snapshot['provenance']['source_commit']=head
(out/'metadata.json').write_text(json.dumps(snapshot,indent=2)+'\n')
original=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{0})
class Args:experiment='EXP-009';run='DEVELOPMENT';session=1;cpu=0
try:code=run.execute(out,snapshot,run.load_protocol(),Args(),original)
finally:os.sched_setaffinity(0,set(original))
print('Development exit',code)
sys.exit(code)
